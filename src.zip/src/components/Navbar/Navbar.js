"use client"

import { useState, useEffect, useCallback } from "react"
import "./Navbar.css"
import "./MenuDropdown.css"
import { BiSolidPlaneAlt, BiGroup } from "react-icons/bi"
import { PiWrench } from "react-icons/pi"
import { IoMdMenu, IoMdClose } from "react-icons/io"
import { MdOutlineStarBorder, MdDashboard } from "react-icons/md"
import { HiOutlineDotsHorizontal } from "react-icons/hi"
import { IoPerson } from "react-icons/io5"

import viewOptions from "../../content/viewOptions.json"

import { FaTable, FaRegCalendarAlt, FaAlgolia, FaMapMarkerAlt, FaLock } from "react-icons/fa"
import { RiBook2Fill } from "react-icons/ri"
import { GiConsoleController } from "react-icons/gi"
import { IoMailOutline } from "react-icons/io5"
import { MdLabelImportantOutline } from "react-icons/md"
import Dropdown from "../Dropdown/Dropdown"
import { Link, NavLink } from "react-router-dom"
import { MdOutlineFeedback } from "react-icons/md"
import { RiStarSFill } from "react-icons/ri"
import { MdLockOutline } from "react-icons/md"

const iconMap = {
  FaTable,
  FaRegCalendarAlt,
  FaAlgolia,
  FaMapMarkerAlt,
  FaLock,
  MdDashboard,
  RiBook2Fill,
  GiConsoleController,
  IoMailOutline,
  MdOutlineFeedback,
  IoMdClose,
}

const Navbar = () => {
  const [activeDropdown, setActiveDropdown] = useState(null)
  const [activeTab, setActiveTab] = useState("members")

  /**
   * Toggle dropdown safely using functional state update
   * This ensures only one dropdown is active at a time
   */
  const toggleDropdown = useCallback((dropdownName, e) => {
    if (e) {
      e.stopPropagation()
      e.preventDefault()
    }
    setActiveDropdown((prev) => {
      if (prev === dropdownName) return null
      return dropdownName
    })
  }, [])

  /**
   * Handle outside click and Escape key to close dropdowns
   */
  useEffect(() => {
    if (!activeDropdown) return

    const handleClickOutside = (event) => {
      const isInside = event.target.closest(
        `.dropdown-card, 
         .card-popup, 
         .menu-dropdown, 
         .profile-popup, 
         .app-dropdown-btn,
         .app-active-link,
         .modal-content,
         [data-dropdown="${activeDropdown}"]`,
      )

      if (!isInside) {
        setActiveDropdown(null)
      }
    }

    const handleEscape = (e) => {
      if (e.key === "Escape") {
        setActiveDropdown(null)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    document.addEventListener("keydown", handleEscape)

    if (activeDropdown === "share") {
      document.body.style.overflow = "hidden"
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
      document.removeEventListener("keydown", handleEscape)
      document.body.style.overflow = ""
    }
  }, [activeDropdown])
  return (
    <nav className="app-navbar">
      <div className="app-navbar-left gap-sm-4 gap-2">
        <h2 className="app-logo">Aut eum omnis consec</h2>

        <div className="nav-icon-wrapper">
          <div className="nav-left-icon" data-dropdown="menu" onClick={(e) => toggleDropdown("menu", e)}>
            <div className="bx bx-menu-alt-right" />
            <div className="bx bx-chevron-down fs-5" />
          </div>

          {activeDropdown === "menu" && (
            <Dropdown
              className=""
              style={{ padding: "8px" }}
              header={
                <div className="app-dropdown-header">
                  <h2 className="app-dropdown-title">Upgrade for views</h2>
                  <div
                    className="bx bx-x nav-close-icon"
                    data-dropdown-toggle="menu"
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleDropdown("menu")
                    }}
                  />
                </div>
              }
              content={
                <div className="app-dropdown-content">
                  <div className="app-d-content-title">
                    <div className="bx bx-card" />
                    Board
                  </div>
                  <ul className="app-d-contentlist">
                    {viewOptions.map((option) => {
                      const IconLeft = iconMap[option.leftIcon]
                      const IconRight = iconMap[option.rightIcon]
                      return (
                        <li key={option.id} className="app-d-content-item">
                          <div className="app-d-content-left">
                            <IconLeft className="app-d-icon" />
                            <span>{option.name}</span>
                          </div>
                          <IconRight className="app-d-icon" />
                        </li>
                      )
                    })}
                  </ul>
                </div>
              }
              bottom={
                <div className="app-dropdown-bottom">
                  <h2 className="app-bottom-title">See your work in new ways</h2>
                  <div className="app-d-bottom-content">
                    <p>
                      View key timelines, assignments, data, and more directly from your Trello board with Trello
                      Premium.
                    </p>
                  </div>
                  <button className="app-dropdown-btn">Start free trial</button>

                  <p className="app-special">
                    <NavLink
                      to="/"
                      onClick={() => toggleDropdown("menu")}
                      className={({ isActive }) => (isActive ? "app-active-link" : "app-default-link")}
                    >
                      Learn more about trello premium
                    </NavLink>
                  </p>
                </div>
              }
            />
          )}
          <span className="app-tool-tip">Views</span>
        </div>
      </div>

      <div className="app-navbar-right gap-2 gap-sm-4 ">
        <div className="nav-icon-wrapper ">
          <div className="app-nav-avatar" data-dropdown="profile" onClick={(e) => toggleDropdown("profile", e)}>
            AT
          </div>
          <span className="app-tool-tip">Profile</span>
          {activeDropdown === "profile" && (
            <div className="profile-popup ">
              <div className="profile-header">
                <div
                  className="bx bx-x profile-close text-black"
                  onClick={(e) => {
                    e.stopPropagation()
                    setActiveDropdown(null)
                  }}
                />
                <div className="profile-avatar">AT</div>
                <div className="profile-user-info">
                  <div className="profile-name">Aamir Tariq</div>
                  <div className="profile-username">@aamirtariq1</div>
                </div>
              </div>
              <div className="profile-option">Edit profile info</div>
              <hr className="profile-divider" />
              <div className="profile-option">View member's board activity</div>
            </div>
          )}
        </div>

        <div
          className="nav-icon-wrapper d-md-block d-none"
          data-dropdown="ups"
          onClick={(e) => toggleDropdown("ups", e)}
        >
          <BiSolidPlaneAlt className="app-nav-icon" />
          <span className="app-tool-tip">Plane</span>
          {activeDropdown === "ups" && (
            <Dropdown
              style={{ padding: "0 18px" }}
              header={
                <div className="ups-dropdown-header">
                  <h2 className="ups-dropdown-title">Power-Ups</h2>
                  <div
                    className="bx bx-x profile-close text-white"
                    onClick={(e) => {
                      e.stopPropagation()
                      setActiveDropdown(null)
                    }}
                  />
                </div>
              }
              content={
                <div className="ups-dropdown-content">
                  <img src="/powers-img.jpg" alt="Power-Ups" className="ups-dropdown-img" />
                  <p>Bring additional features to your boards and integrate app like Google Drive, Slack, and more.</p>
                </div>
              }
              bottom={
                <div className="ups-dropdown-bottom">
                  <button className="app-dropdown-btn" id="ups-btn">
                    Add power-ups
                  </button>
                </div>
              }
            />
          )}
        </div>

        <div
          className="nav-icon-wrapper d-md-block d-none"
          data-dropdown="setting"
          onClick={(e) => toggleDropdown("setting", e)}
        >
          <PiWrench className="app-nav-icon" />
          <span className="app-tool-tip">Settings</span>
          {activeDropdown === "setting" && (
            <div className="card-popup" id="popup-info">
              <div className="popup-header">
                <h6 className="popup-title">Automation</h6>
                <span
                  className="close-btn"
                  onClick={(e) => {
                    e.stopPropagation()
                    setActiveDropdown(null)
                  }}
                >
                  ×
                </span>
              </div>
              <div className="popup-content">
                <div className="popup-item">
                  <RiBook2Fill className="popup-icon" />
                  <div className="popup-item-content">
                    <strong>Rules</strong>
                    <p>Lorem ipsum dolor sit amet psum dolor laboriosam!</p>
                  </div>
                </div>
                <div className="popup-item">
                  <GiConsoleController className="popup-icon" />
                  <div className="popup-item-content">
                    <strong>Button</strong>
                    <p>Lorem ipsum dolor sit amet psum dolor laboriosam!</p>
                  </div>
                </div>
                <div className="popup-item">
                  <IoMailOutline className="popup-icon" />
                  <div className="popup-item-content">
                    <strong>Email</strong>
                    <p>Lorem ipsum dolor sit amet psum dolor laboriosam!</p>
                  </div>
                </div>
                <div className="popup-item">
                  <MdOutlineFeedback className="popup-icon" />
                  <div className="popup-item-content">
                    <strong>Feedback</strong>
                    <p>Lorem ipsum dolor sit amet psum dolor laboriosam!</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="nav-icon-wrapper d-md-block d-none">
          <div className="app-nav-icon" data-dropdown="newmenu" onClick={(e) => toggleDropdown("newmenu", e)}>
            <IoMdMenu />
            <span className="app-tool-tip">Menu</span>
          </div>

          {activeDropdown === "newmenu" && (
            <div className="menu-dropdown">
              <div className="menu-header mt-4">
                <h6 className="menu-title">Filter</h6>
                <button
                  className="newmenue-close-btn"
                  onClick={(e) => {
                    e.stopPropagation()
                    setActiveDropdown(null)
                  }}
                  aria-label="Close menu"
                >
                  <div className="bx bx-x" />
                </button>
              </div>

              <div className="menu-content">
                <div className="menu-section">
                  <label className="menu-label mb-2">Keyword</label>
                  <input type="text" placeholder="Enter a keyword..." className="menu-input" />
                  <small className="menu-hint">Search cards, members, labels, and more.</small>
                </div>

                <div className="menu-section">
                  <label className="menu-label">Members</label>
                  <label className="menu-option">
                    <input type="checkbox" id="noMembers" />
                    <span className="menu-icon">
                      <IoPerson />
                    </span>
                    <span>No members</span>
                  </label>
                  <label className="menu-option">
                    <input type="checkbox" id="assignedToMe" />
                    <div className="avatar">AT</div>
                    <span>Cards assigned to me</span>
                  </label>
                </div>

                <div className="menu-section">
                  <label className="menu-label">Card status</label>
                  <label className="menu-option">
                    <input type="checkbox" />
                    <span>Marked as complete</span>
                  </label>
                  <label className="menu-option">
                    <input type="checkbox" />
                    <span>Not marked as complete</span>
                  </label>
                </div>

                <div className="menu-section">
                  <label className="menu-label">Due date</label>
                  <label className="menu-option">
                    <input type="checkbox" />
                    <span>No dates</span>
                  </label>
                  <label className="menu-option">
                    <input type="checkbox" />
                    <span>Overdue</span>
                  </label>
                  <label className="menu-option">
                    <input type="checkbox" />
                    <span>Due in the next day</span>
                  </label>
                </div>

                <div className="menu-section">
                  <label className="menu-label">Labels</label>
                  <label className="menu-option">
                    <input type="checkbox" id="noLabels" />
                    <span className="menu-icon">
                      <MdLabelImportantOutline />
                    </span>
                    <span>No labels</span>
                  </label>
                  <div className="label-colors">
                    <div className="label-color green" title="Green" />
                    <div className="label-color yellow" title="Yellow" />
                    <div className="label-color orange" title="Orange" />
                  </div>
                  <select className="menu-dropdown-select">
                    <option>Select labels</option>
                  </select>
                </div>
              </div>
            </div>
          )}
        </div>

        <div
          className="nav-icon-wrapper d-md-block d-none"
          data-dropdown="star"
          onClick={(e) => toggleDropdown("star", e)}
        >
          <MdOutlineStarBorder className="app-nav-icon" />
          <span className="app-tool-tip">Star</span>
          {activeDropdown === "star" && (
            <div>
              <div className="card-popup" id="popup-star">
                <div className="d-flex justify-content-between align-items-center border-0">
                  <h6 className="upgrade-title m-0 mx-auto mt-2">Favorites</h6>
                  <IoMdClose
                    onClick={(e) => {
                      e.stopPropagation()
                      setActiveDropdown(null)
                    }}
                  />
                </div>
                <p>Starred boards and items will appear here.</p>
                <div className="rating">
                  <RiStarSFill className="star-icon" />
                  <RiStarSFill className="star-icon" />
                  <RiStarSFill className="star-icon" />
                  <RiStarSFill className="star-icon" />
                  <RiStarSFill className="star-icon" />
                  <span style={{ marginLeft: "8px" }}>4.5</span>
                </div>
              </div>
            </div>
          )}
        </div>

        <div
          className="nav-icon-wrapper d-md-block d-none"
          data-dropdown="group"
          onClick={(e) => toggleDropdown("group", e)}
        >
          <BiGroup className="app-nav-icon" />
          <span className="app-tool-tip">Group</span>
          {activeDropdown === "group" && (
            <div>
              <div className="card-popup" id="popup-visibility">
                <div className="d-flex justify-content-between align-items-center mb-2">
                  <h6 className="upgrade-title mx-auto text-secondary ">Change visibility</h6>
                  <div className="bx bx-x fs-5" />
                </div>
                <p className="">
                  <MdLockOutline className="me-1" />
                  <strong>Private</strong>
                </p>
                <p>Lorem ipsum dolor sit amet psum dolor laboriosam!</p>
                <p />
                <p className=" my-1">
                  <BiGroup className=" me-1 " />
                  <strong>Workspace</strong>
                </p>
                <p>Lorem ipsum dolor sit amet psum dolor laboriosam!</p>
                <p />
                <p className=" my-1">
                  <BiGroup className=" me-1" />
                  <strong>Organize all</strong>
                </p>
                <p>Lorem ipsum dolor sit amet psum dolor laboriosam!</p>
                <p />
                <p className=" my-1">
                  <IoPerson className="me-1" />
                  <strong>Public</strong>
                </p>
                <p>Lorem ipsum dolor sit amet psum dolor laboriosam!</p>
                <p />
              </div>
            </div>
          )}
        </div>

        <div className=" d-md-block d-none">
          <button className="app-nav-btn" data-dropdown="share" onClick={(e) => toggleDropdown("share", e)}>
            Share
          </button>

          {/* Modal Backdrop */}
          {activeDropdown === "share" && (
            <div
              className="modal-backdrop show"
              style={{
                backgroundColor: "rgba(0, 0, 0, 0.5)",
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                zIndex: 1040,
              }}
              onClick={(e) => {
                if (e.target === e.currentTarget) {
                  setActiveDropdown(null)
                }
              }}
            ></div>
          )}

          {/* Modal */}
          <div className={`modal ${activeDropdown === "share" ? "show d-block" : "d-none"}`}>
            <div
              className="modal-dialog modal-dialog-centered modal-md"
              role="document"
              onClick={(e) => e.stopPropagation()}
            >
              <div
                className="modal-content custom-modal-content"
                style={{
                  margin: "1.75rem auto",
                  maxWidth: "500px",
                }}
              >
                <div className="modal-header border-0">
                  <h5 className="modal-title ">Share board</h5>
                  <button
                    type="button"
                    className="btn-close btn-close-white"
                    onClick={(e) => {
                      e.stopPropagation()
                      setActiveDropdown(null)
                    }}
                    aria-label="Close"
                  />
                </div>
                <div className="modal-body">
                  <div className="mb-3 d-flex">
                    <input type="text" className="form-control me-2 custom-input" placeholder="Email address or name" />
                    <select className="form-select custom-select me-2" style={{ width: "auto" }}>
                      <option>Member</option>
                      <option>Admin</option>
                    </select>
                    <button className="btn btn-primary">Share</button>
                  </div>
                  <div className="mb-3">
                    <Link href="/" className="text-link">
                      Create link
                    </Link>
                  </div>

                  {/* Tabs Navigation */}
                  <ul className="nav nav-tabs border-secondary mb-3" role="tablist">
                    <li className="nav-item" role="presentation">
                      <button
                        className={`nav-link ${
                          activeTab === "members" ? "active bg-white bg-opacity-10 " : ""
                        }  border-0`}
                        onClick={() => setActiveTab("members")}
                        role="tab"
                        aria-selected={activeTab === "members"}
                      >
                        Board members <span className="badge bg-secondary">1</span>
                      </button>
                    </li>
                    <li className="nav-item" role="presentation">
                      <button
                        className={`nav-link ${activeTab === "requests" ? "active bg-white bg-opacity-10  " : ""} `}
                        onClick={() => setActiveTab("requests")}
                        role="tab"
                        aria-selected={activeTab === "requests"}
                      >
                        Join requests
                      </button>
                    </li>
                  </ul>

                  {/* Tab Content */}
                  <div className="tab-content">
                    {/* Board Members Tab */}
                    <div className={`tab-pane fade ${activeTab === "members" ? "show active" : ""}`} role="tabpanel">
                      <div className="member-box mt-3">
                        <div>
                          <strong>Aamir Tariq (you)</strong>
                          <br />
                          <small>@aamirtariq1 • Workspace admin</small>
                        </div>
                        <select className="form-select form-select-sm" style={{ width: "auto" }}>
                          <option>Member</option>
                          <option>Admin</option>
                          <option>Remove</option>
                        </select>
                      </div>

                      {/* Add more members here */}
                      <div className="member-box mt-3">
                        <div>
                          <strong>John Doe</strong>
                          <br />
                          <small>@johndoe • Member</small>
                        </div>
                        <select className="form-select form-select-sm" style={{ width: "auto" }}>
                          <option>Member</option>
                          <option>Admin</option>
                          <option>Remove</option>
                        </select>
                      </div>
                    </div>

                    {/* Join Requests Tab */}
                    <div className={`tab-pane fade ${activeTab === "requests" ? "show active " : ""}`} role="tabpanel">
                      <div className="text-center py-4">
                        <p>No pending join requests</p>
                        <button className="btn btn-sm btn-outline-light mt-2">
                          <i className="bi bi-people me-1"></i>
                          Invite members
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div>
          <div className="dropdown">
            <HiOutlineDotsHorizontal
              className="app-nav-icon-dots"
              data-dropdown="dot"
              onClick={(e) => toggleDropdown("dot", e)}
              id="dropdownMenuButton"
              data-bs-toggle="dropdown"
              aria-expanded={activeDropdown === "dot" ? "true" : "false"}
            />
            <ul
              className={`dropdown-menu dropdown-menu-end dropdown-card ${activeDropdown === "dot" ? "show" : ""}`}
              aria-labelledby="dropdownMenuButton"
              style={{
                position: "absolute",
                inset: "0px auto auto 0px",
                margin: "0px",
                transform: "translate(-220px, 40px)",
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <li>
                <a className="dropdown-item" href="/">
                  <div className="dropdown-avatar">AT</div>
                  Profile
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-bell"></i>
                  Notifications
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-bolt-circle"></i>
                  Power-Ups
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-star"></i>
                  Favorites
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-info-circle"></i>
                  Info
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-log-out"></i>
                  Log out
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-cog"></i> Settings
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-palette"></i> Change background
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-upload"></i> Upgrade
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-file"></i> Start free trial
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-rocket"></i> Automation
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-puzzle"></i> Power-Ups
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-label"></i> Labels
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-sticker"></i> Stickers
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-template"></i> Make template
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-list-check"></i> Activity
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-archive"></i> Archived items
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-show"></i> Watch
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-copy-alt"></i> Copy board
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-mail-send"></i> Email-to-board
                </a>
              </li>
              <li>
                <a className="dropdown-item" href="/">
                  <i className="bx bx-window-close"></i> Close board
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
